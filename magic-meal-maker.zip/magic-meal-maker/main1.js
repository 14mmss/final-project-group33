angular.module('KRRclass', [ 'chart.js']).controller('MainCtrl', ['$scope','$http', mainCtrl]);

function mainCtrl($scope, $http){
	$scope.meals = {};

	$scope.startMyAwesomeApp = function(){
		$scope.myDisplayMessage = `You chose a meal that is ${$scope.dietChoice} for ${$scope.typeChoice}. You can make these meals:`;
		$scope.mySparqlEndpoint = "http://192.168.68.127:7200/repositories/project" ;

		let ingredient1 = document.getElementById("ingredient1").value;
		let ingredient2 = document.getElementById("ingredient2").value;

		if (ingredient1 == "" || ingredient2 == "") {
				alert("Both ingredients are required");
				location.reload();
		}

		const filters = [];

		if ($scope.dietChoice == "Vegan"){
			filters.push(`FILTER NOT EXISTS {?ingredients rdf:type ex:Dairy} .`)
			filters.push(`FILTER NOT EXISTS {?ingredients rdf:type ex:Meat} .`)
			filters.push(`FILTER NOT EXISTS {?ingredients rdf:type ex:Egg} .`)
			filters.push(`FILTER NOT EXISTS {?ingredients rdf:type ex:NotVegan} .`)
			filters.push(`FILTER NOT EXISTS {?ingredients rdf:type ex:Fish} .`)
		}

		if ($scope.dietChoice == "Vegetarian"){
			filters.push(`FILTER NOT EXISTS {?meal rdf:type ex:ContainsMeat} .`)
			filters.push(`FILTER NOT EXISTS {?meal rdf:type ex:Pescatarian} .`)
		}

		if ($scope.dietChoice == "Meat"){
			filters.push(`?meal rdf:type ex:ContainsMeat .`)
		}

		if ($scope.dietChoice == "Dairy Free"){
			filters.push(`FILTER NOT EXISTS {?meal rdf:type ex:ContainsDairy} .`)
		}

		if ($scope.dietChoice == "Pescatarian"){
			filters.push(`?meal rdf:type ex:Pescatarian .`)
		}

		 if ($scope.typeChoice == "Breakfast"){
			 filters.push(`?meal rdf:type ex:Breakfast .`)
		 }

		 if ($scope.typeChoice == "Lunch"){
			 filters.push(`?meal rdf:type ex:Lunch .`)
		 }

		 if ($scope.typeChoice == "Dinner"){
			 filters.push(`?meal rdf:type ex:Dinner .`)
		 }
	

		 const query = `PREFIX ex: <http://www.example.com/project/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX wd: <http://www.wikidata.org/entity/>

SELECT DISTINCT ?mealName ?ingredientsName ?measure ?calories WHERE {
 ?meal rdf:type ex:Meal ;
			 ex:hasIngredient ?ingredient1;
			 ex:hasIngredient ?ingredient2;
			 ex:hasIngredient ?ingredients;
		 rdfs:label ?mealName .
	?ingredient1 rdfs:label "${ingredient1}"@en .
	?ingredient2 rdfs:label "${ingredient2}"@en .
	?ingredients rdfs:label ?ingredientsName .
	${filters.join(" \n")}
 OPTIONAL{?ingredients ex:hasMeasurement ?measure}
 OPTIONAL{?ingredients ex:hasCalories ?calories .}

}`
		console.log(query)

		$http( {
			method: "GET",
			url : $scope.mySparqlEndpoint + "?query=" + encodeURI(query).replace(/#/g, '%23'),
			headers : {'Accept':'application/sparql-results+json', 'Content-Type':'application/sparql-results+json'}
		} )
		.success(function(data, status ) {
			$scope.meals = {};

						document.getElementById("diet").style.display = "none";
            document.getElementById("mealtimeselect").style.display = "none";
            document.getElementById("myBtn").style.display = "none";

			data.results.bindings.forEach(({ calories, ingredientsName, mealName, measure }) => {
				if (!$scope.meals.hasOwnProperty(mealName.value)) {
					$scope.meals[mealName.value] = [];
				}

				$scope.meals[mealName.value].push({
					name: ingredientsName.value,
					calories: calories ? calories.value : "No calories found",
					measure: measure ? measure.value : "No measurement found",
				});
			});
			if (!Array.isArray(data.results.bindings) || !data.results.bindings.length) {
                alert("There are no meals for the restrictions provided");
                location.reload();
            }
		})
		.error(function(error ){
			console.log('Error running the input query!'+error);
		});

};

}

function autocomplete(inp, arr) {
  /*the autocomplete function takes two arguments,
  the text field element and an array of possible autocompleted values:*/
  var currentFocus;
  /*execute a function when someone writes in the text field:*/
  inp.addEventListener("input", function(e) {
      var a, b, i, val = this.value;
      /*close any already open lists of autocompleted values*/
      closeAllLists();
      if (!val) { return false;}
      currentFocus = -1;
      /*create a DIV element that will contain the items (values):*/
      a = document.createElement("DIV");
      a.setAttribute("id", this.id + "autocomplete-list");
      a.setAttribute("class", "autocomplete-items");
      /*append the DIV element as a child of the autocomplete container:*/
      this.parentNode.appendChild(a);
      /*for each item in the array...*/
      for (i = 0; i < arr.length; i++) {
        /*check if the item starts with the same letters as the text field value:*/
        if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
          /*create a DIV element for each matching element:*/
          b = document.createElement("DIV");
          /*make the matching letters bold:*/
          b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
          b.innerHTML += arr[i].substr(val.length);
          /*insert a input field that will hold the current array item's value:*/
          b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
          /*execute a function when someone clicks on the item value (DIV element):*/
              b.addEventListener("click", function(e) {
              /*insert the value for the autocomplete text field:*/
              inp.value = this.getElementsByTagName("input")[0].value;
              /*close the list of autocompleted values,
              (or any other open lists of autocompleted values:*/
              closeAllLists();
          });
          a.appendChild(b);
        }
      }
  });
  /*execute a function presses a key on the keyboard:*/
  inp.addEventListener("keydown", function(e) {
      var x = document.getElementById(this.id + "autocomplete-list");
      if (x) x = x.getElementsByTagName("div");
      if (e.keyCode == 40) {
        /*If the arrow DOWN key is pressed,
        increase the currentFocus variable:*/
        currentFocus++;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 38) { //up
        /*If the arrow UP key is pressed,
        decrease the currentFocus variable:*/
        currentFocus--;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 13) {
        /*If the ENTER key is pressed, prevent the form from being submitted,*/
        e.preventDefault();
        if (currentFocus > -1) {
          /*and simulate a click on the "active" item:*/
          if (x) x[currentFocus].click();
        }
      }
  });
  function addActive(x) {
    /*a function to classify an item as "active":*/
    if (!x) return false;
    /*start by removing the "active" class on all items:*/
    removeActive(x);
    if (currentFocus >= x.length) currentFocus = 0;
    if (currentFocus < 0) currentFocus = (x.length - 1);
    /*add class "autocomplete-active":*/
    x[currentFocus].classList.add("autocomplete-active");
  }
  function removeActive(x) {
    /*a function to remove the "active" class from all autocomplete items:*/
    for (var i = 0; i < x.length; i++) {
      x[i].classList.remove("autocomplete-active");
    }
  }
  function closeAllLists(elmnt) {
    /*close all autocomplete lists in the document,
    except the one passed as an argument:*/
    var x = document.getElementsByClassName("autocomplete-items");
    for (var i = 0; i < x.length; i++) {
      if (elmnt != x[i] && elmnt != inp) {
      x[i].parentNode.removeChild(x[i]);
    }
  }
}
/*execute a function when someone clicks in the document:*/
document.addEventListener("click", function (e) {
    closeAllLists(e.target);
});
}
var ingredientsList;
ingredientsList = ["beef",
									"vegetable",
									"butter",
									"bread",
									"red wine",
									"broth",
									"shrimp",
									"Chili Powder",
									"garlic",
									"veal",
									"tofu",
									"cooking oil",
									"rice",
									"cheese",
									"Spätzle",
									"fried onion",
									"egg",
									"flour",
									"olive oil",
									"table salt",
									"pork ribs",
									"blood sausage",
									"potato",
									"tomato",
									"saffron",
									"water",
									"chickpea",
									"sodium chloride",
									"eggplant",
									"white cabbage",
									"honey",
									"raisin",
									"millet",
									"quark",
									"clarified butter",
									"white sugar",
									"sauerkraut",
									"globe artichoke",
									"Capsicum annuum",
									"feta",
									"macaroni",
									"pickled vegetable",
									"pig's trotters",
									"sauce",
									"chicken",
									"chicken egg",
									"syrup",
									"nori",
									"peanut butter",
									"unagi",
									"jam",
									"mayonnaise",
									"beet",
									"apple",
									"Allium",
									"white sauce",
									"Allium sativum",
									"Black truffle",
									"puff pastry",
									"foie gras",
									"parsley",
									"white wine",
									"Cointreau",
									"lemon",
									"orange",
									"onion",
									"Piper nigrum",
									"duck meat",
									"carrot",
									"bouquet garni",
									"noodle",
									"shoestring potatoes",
									"scrambled eggs",
									"Madeira sauce",
									"kidney",
									"white bread",
									"caraway seeds",
									"grated cheese",
									"pepper",
									"milk",
									"mozzarella",
									"tomato sauce",
									"oils",
									"bell pepper",
									"marjoram",
									"basil",
									"zucchini",
									"meat",
									"bean",
									"Allium cepa",
									"endive",
									"minced meat",
									"peanut sauce",
									"Phaseolus lunatus",
									"green bean",
									"rabbit",
									"lard",
									"semolina",
									"drinking water",
									"Thunnus",
									"lentil",
									"Xanthosoma sagittifolium",
									"mango",
									"Curcuma longa",
									"cream",
									"sugar",
									"maize",
									"lamb meat",
									"banana",
									"Salzgurke",
									"mustard",
									"hard-boiled egg",
									"Piper",
									"Apium",
									"crmgweñ",
									"pea",
									"Daucus",
									"beer",
									"okra",
									"wheat tortilla",
									"chorizo",
									"avocado",
									"toast",
									"pumpkin",
									"kimchi",
									"cod",
									"cow's milk",
									"dough",
									"paprika",
									"lemon juice",
									"whole wheat bread",
									"sweet potato",
									"salt",
									"corn flour",
									"olive",
									"Origanum",
									"yeast",
									"pork meat",
									"sausage",
									"liver",
									"salami",
									"smoked Provola",
									"meatball",
									"warm water",
									"spice",
									"goat meat",
									"cauliflower",
									"ham",
									"seafood",
									"omelette",
									"algae",
									"yogurt",
									"crayfish",
									"pasta",
									"turkey meat",
									"rosemary",
									"Thymus",
									"bay leaf",
									"ice cream",
									"biscuit",
									"meringue",
									"bacon",
									"soda bread",
									"potato bread",
									"coriander seed",
									"Phaseolus vulgaris",
									"stock",
									"kale",
									"sesame seed",
									"black turtle bean",
									"cinnamon",
									"garlic clove",
									"cumin seed",
									"yellow onion",
									"mutton",
									"stockfish",
									"broccoli",
									"namul",
									"gochujang",
									"bun",
									"pickle",
									"Vigna radiata",
									"coconut milk",
									"ginger",
									"chili pepper",
									"coconut",
									"brussels sprouts",
									"spinach",
									"taco",
									"coriander leaf",
									"coleslaw",
									"lettuce",
									"patty",
									"cabbage",
									"hemp oil",
									"tonkatsu",
									"wheat flour",
									"Cheddar cheese",
									"jalapeño",
									"watermelon",
									"corn tortilla",
									"dairy product",
									"fruit",
									"duck",
									"salt and pepper",
									"French toast",
									"Bananas Foster",
									"celery",
									"cayenne pepper",
									"green bell pepper",
									"roux",
									"five-spice powder",
									"brown sugar",
									"lime",
									"Allspice",
									"soy sauce",
									"thyme",
									"scallion",
									"alligator",
									"roast beef",
									"Fior di latte",
									"Parmesan cheese"]
